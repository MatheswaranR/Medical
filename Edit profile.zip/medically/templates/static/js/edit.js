function setAllFieldsRequired() {
    var formElements = document.getElementsByClassName("form-element");
    for (var i = 0; i < formElements.length; i++) {
        var inputField = formElements[i].querySelector("input, select");
        if (inputField) {
            inputField.setAttribute("required", "true");
        }
    }
}

document.addEventListener("DOMContentLoaded", function() {
    setAllFieldsRequired();
});
function validateForm() {
    var firstName = document.getElementById("first-name").value;
    var firstNameRegex = /^[a-zA-Z]+$/;
    if (!firstNameRegex.test(firstName)) {
        alert("First name must contain only alphabets.");
        return false;
    }
    var lastName = document.getElementById("last-name").value;
    var lastNameRegex = /^[a-zA-Z]+$/;
    if (!lastNameRegex.test(lastName)) {
        alert("Last name must contain only alphabets.");
        return false;
    }
    var otherFields = document.querySelectorAll('input[type="text"]');
    for (var i = 0; i < otherFields.length; i++) {
        var fieldValue = otherFields[i].value;
        var fieldRegex = /^[a-zA-Z0-9]+$/;
        if (!fieldRegex.test(fieldValue)) {
            alert("Please enter alphanumeric characters only.");
            return false;
        }
    }
    return true;
}