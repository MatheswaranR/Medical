function showModal() {
    var myModal = new bootstrap.Modal(document.getElementById('editModal'));
    myModal.show();
}

window.onload = function() {
    showModal();
};

// Function to validate form
function validateForm() {
    var form = document.getElementById("experienceForm");
    var description = document.getElementById("description").value.trim();
    var descriptionWordCount = description.split(/\s+/).length;

    if (descriptionWordCount > 1000) {
        alert("Description cannot exceed 1000 words.");
        return;
    }

    if (form.checkValidity()) {
        form.submit();
    } else {
        alert("Please fill out all required fields.");
    }
}