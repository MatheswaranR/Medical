function uploadFile() {
    var files = document.getElementById("media").files;
    var uploadedFilesDiv = document.getElementById("uploadedFiles");
    var uploadSuccessMessage = document.getElementById("uploadSuccessMessage");

    if (files.length === 0) {
        alert("Please select a file to upload.");
        return;
    }

    uploadedFilesDiv.innerHTML = "";

    for (var i = 0; i < files.length; i++) {
        var file = files[i];
        var fileName = file.name;
        var fileSize = file.size;

        var fileItem = document.createElement("p");
        fileItem.textContent = "File Name: " + fileName + ", File Size: " + fileSize + " bytes";
        uploadedFilesDiv.appendChild(fileItem);
    }

    uploadSuccessMessage.style.display = "block";
}


window.onload = function() {
    var mediaModal = new bootstrap.Modal(document.getElementById('mediaModal'));
    mediaModal.show();
};