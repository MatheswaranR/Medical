function showtxt() {
    var x = document.getElementById("imgtxt");
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
  }
  
  // Function to open a popup
  function openPopup(imageSrc) {
    var modal = document.createElement("div");
    modal.classList.add("modal", "fade", "show");
    modal.setAttribute("tabindex", "-1");
    modal.setAttribute("role", "dialog");
    modal.style.display = "block";
    modal.innerHTML = `
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Joined Circle</h5>
            <button type="button" class="btn-close" aria-label="Close" onclick="closeCircle()"></button>
          </div>
          <div class="modal-body">
            <div class="circle-description">
              <h2>Description</h2>
              <p>This is a brief description of the joined circle. It will be displayed at the top center of the box.</p>
            </div>
            <div class="circle-box2">
              <h2>Image of the doctor.</h2>
              <img src="${imageSrc}" alt="Circle Image" class="circle-image">
            </div>
          </div>
        </div>
      </div>`;
    document.body.appendChild(modal);
  }
  
  // Function to close the popup
  function closeCircle() {
    var modal = document.querySelector('.modal');
    modal.remove();
  }
  
  // Handle join circle button click
  document.querySelectorAll('.jc').forEach(btn => {
    btn.addEventListener('click', function () {
      var imageSrc = this.getAttribute('data-image');
      openPopup(imageSrc);
    });
  });
  
  // Function to open the notification popup
  function openNotificationPopup(htmlFile) {
    // Fetch the HTML content
    fetch(htmlFile)
      .then(response => response.text())
      .then(html => {
        // Create a modal container
        var modal = document.createElement("div");
        modal.classList.add("modal", "fade", "show");
        modal.setAttribute("tabindex", "-1");
        modal.setAttribute("role", "dialog");
        modal.style.display = "block";
        modal.innerHTML = html;
        // Append the modal to the body
        document.body.appendChild(modal);
      })
      .catch(error => console.error('Error fetching notification:', error));
  }
  
  // Function to close the notification popup
  function closeNotification() {
    var notification = document.querySelector('.modal');
    notification.remove();
  }
  
  // Add event listener to the notification icon
  document.querySelector('.d-flex img[src="/static/images/notifi.png"]').addEventListener('click', function () {
    // Display the notification popup from message.html
    openNotificationPopup('message.html');
  });
  
  // Add event listener to the message icon
  document.querySelector('.d-flex img[src="/static/images/message.png"]').addEventListener('click', function () {
    // Display the notification popup from notify1.html
    openNotificationPopup('sa.html');
  });
  function joinCircle(button) {
    // Update the button text to "Joined"
    button.innerText = "Joined";
  
    // Get the follower count element
    var followerCountElement = document.getElementById("followerCount");
  
    // Extract the current follower count
    var followerCountText = followerCountElement.innerText;
    var followerCount = parseInt(followerCountText);
    followerCount++;
    followerCountElement.innerText = followerCount + "M Followers";
  }