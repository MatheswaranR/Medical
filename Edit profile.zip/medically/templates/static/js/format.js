document.addEventListener('DOMContentLoaded', function() {
    var modal = new bootstrap.Modal(document.getElementById('editModal'));
    document.getElementById('yesBtn').addEventListener('click', function() {
        alert('Thank you for your feedback!'); 
    });
    document.getElementById('noBtn').addEventListener('click', function() {
        alert('We\'ll try to improve!'); 
    });

    modal.show();
});