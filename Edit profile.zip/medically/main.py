from fastapi import FastAPI,Request,Depends,Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import RedirectResponse,JSONResponse
from database import SessionLocal
from fastapi.encoders import jsonable_encoder
from sqlalchemy.orm import Session
from models import base
import models

app=FastAPI()
templates = Jinja2Templates(directory='templates')
app.mount("/templates/static",StaticFiles(directory="templates/static"), name="static")

def get_db():
    db = None
    try:
        db = SessionLocal()
        yield db
    finally:
        db.close()

# Get The Template
@app.get('/get_form') 
def get_form(request:Request,db:Session = Depends(get_db)):
    new_user=db.query(models.medically).filter(models.medically.status=="ACTIVE").all()
    return templates.TemplateResponse("/edit.html" ,context={"request":request,"new_id":new_user})

@app.post("/create_data")
def create_data(request: Request, db: Session = Depends(get_db),
                firstname: str = Form(...), lastname: str = Form(...), 
                pronouns: str = Form(...), currentposition: str = Form(...),
                industry: str = Form(...), location: str = Form(...), 
                city: str = Form(...)):
    status = "ACTIVE"
    find = db.query(models.medically).filter(models.medically.firstname == firstname, 
                                             models.medically.status == "ACTIVE").first()
    if find is None:
        body = models.medically(firstname=firstname, lastname=lastname, 
                                pronouns=pronouns, currentposition=currentposition, 
                                industry=industry, location=location, city=city, 
                                status=status)
        db.add(body)
        db.commit()
        error = "Done"
        json_compatible_item_data = jsonable_encoder(error)
        return JSONResponse(content=json_compatible_item_data)
    else:
        error = "A user with this first name already exists."
        json_compatible_item_data = jsonable_encoder(error)
        return JSONResponse(content=json_compatible_item_data)


#add Page

@app.get('/get_form1') 
def get_form(request:Request,db:Session = Depends(get_db)):
    new_user=db.query(models.add).filter(models.add.status=="ACTIVE").all()
    return templates.TemplateResponse("/add.html" ,context={"request":request,"new_id":new_user})

@app.post("/create_data")
def create_data(request: Request, db: Session = Depends(get_db),
                title: str = Form(...), employementtype: str = Form(...), 
                hospitalname: str = Form(...), location: str = Form(...),
                locationtype: str = Form(...), description: str = Form(...), 
                city: str = Form(...)):
    status = "ACTIVE"
    find = db.query(models.add).filter(models.add.title == title, models.add.status == "ACTIVE").first()
    if find is None:
        body = models.add(title=title, employementtype=employementtype, hospitalname=hospitalname,  location= location, 
            locationtype=locationtype,  description=description, skills=skills, status=status)
        db.add(body)
        db.commit()
        error = "Done"
        json_compatible_item_data = jsonable_encoder(error)
        return JSONResponse(content=json_compatible_item_data)
    else:
        error = "A user with this first name already exists."
        json_compatible_item_data = jsonable_encoder(error)
        return JSONResponse(content=json_compatible_item_data)


