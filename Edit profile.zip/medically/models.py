from sqlalchemy import Column, Integer, String, ForeignKey,Float
from sqlalchemy.orm import relationship
from database import base, db_engine
from sqlalchemy.ext.declarative import declarative_base


class medically(base):
    __tablename__ = "medically"

    id = Column(Integer, primary_key=True, index=True)
    firstname= Column(String(30))
    lastname = Column(String(30))
    pronouns = Column(String(30))
    currentposition= Column(String(30))
    industry= Column(String(30))
    location = Column(String(30))
    city = Column(String(30))

    status = Column(String(30))

    # create table registeration ( id int AUTO_INCREMENT PRIMARY KEY,name varchar(30) NOT NULL,dob int NOT NULL,mail_id varchar(30) NOT NULL,father_name varchar(30) NOT NULL,mother_name varchar(30) NOT NULL,gender varchar(30) NOT NULL,category varchar(30) NOT NULL);
base.metadata.create_all(bind=db_engine)

class add(base): 
    __tablename__ = "add"
    id = Column(Integer, primary_key=True, index=True)
    Title= Column(String(30))    
    employementtype= Column(String(30))  
    hospitalname= Column(String(30))
    location = Column(String(30)) 
    locationtype = Column(String(30))
    description = Column(String(255))
    skills = Column(String(30))
    status = Column(String(30))

    # items = relationship("purchase", back_populates="user") 

# create table registeration ( id int AUTO_INCREMENT PRIMARY KEY,name varchar(30) NOT NULL,dob int NOT NULL,mail_id varchar(30) NOT NULL,father_name varchar(30) NOT NULL,mother_name varchar(30) NOT NULL,gender varchar(30) NOT NULL,category varchar(30) NOT NULL);
base.metadata.create_all(bind=db_engine)
