$(document).ready(function () {
    $(".join-circle-btn").click(function () {
        alert("Join Circle button clicked!");
    });
});


$(document).ready(function(){
    $('#editButton').click(function(){
        $('#idproof-modal').modal('show');
    });
});