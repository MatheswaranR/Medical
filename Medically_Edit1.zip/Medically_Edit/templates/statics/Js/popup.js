document.addEventListener('DOMContentLoaded', function () {
    const editButton = document.getElementById('editButton');
    const editPopup = document.getElementById('editPopup');
    const closeButton = document.querySelector('.close');

    editButton.addEventListener('click', function (e) {
        e.preventDefault();
        editPopup.style.display = 'block';
    });

    closeButton.addEventListener('click', function () {
        editPopup.style.display = 'none';
    });

    window.addEventListener('click', function (e) {
        if (e.target === editPopup) {
            editPopup.style.display = 'none';
        }
    });

    const editForm = document.getElementById('editForm');
    editForm.addEventListener('submit', function (e) {
        e.preventDefault();
        console.log('Form submitted');
        editPopup.style.display = 'none';
    });
});
